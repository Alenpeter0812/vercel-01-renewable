<?php
$msg = $msg."Enter Your Name :" . $_POST['name'] ."\n";
$msg = $msg."Enter Your Email :" . $_POST['email']. "\n";
$msg = $msg."Enter Your Phone :" . $_POST['number']. "\n";
$msg = $msg."Enter Your Message :" . $_POST['message']. "\n";

$msgusr = $msgusr."Your Request has been Submitted and we will get back to you soon. In Case of any Importance";
$subject = "Call Back Request ";
$to_1="info@nextgenenergy.com";
$to_2=$_POST["email"];
mail($to_1, $subject, $msg);
mail($to_2, $subject, $msgusr);
$header = "Reply-To: ".$_POST["email"];
header("location:index.html");
?>


